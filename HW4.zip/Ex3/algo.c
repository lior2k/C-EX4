#include <stdio.h>
#include <memory.h>
#include <stdlib.h>
#include "graph.h"
#define n 110
#define Max_Value 999999999
#define Black 1
#define White 0
#define Gray -1

//A 4 n 0 2 5 3 3 n 2 0 4 1 1 n 1 3 7 0 2
//A 3 n 0 2 5 3 3 n 2 0 4 1 1 n 1 3 7 0 2
//A 3 n 0 1 2 2 2 n 1 2 2 n 2 sp - 0 -> 2 w =2
//A 4 n 0 1 1 3 2 n 1 2 2 n 2 3 3 n 3 sp - 0 -> 3 w=2    

void delete_in_edge(pnode temp_node, int src) {
    pedge edge = temp_node -> edges;
    pedge prev_edge = NULL;
    while (edge != NULL) {
        pedge temp = edge;
        if (temp -> endpoint == src) {
            if (prev_edge == NULL) { //indicates first iteration (src node = head node)
                temp_node -> edges = temp -> next;
                free(edge);
                break;
            }
            prev_edge -> next = temp -> next; 
            free(edge);
            break;
        }
        prev_edge = edge;
        edge = edge -> next;
    }
}

void free_node_edges(pnode temp_node) {
    pedge edge = temp_node -> edges;
    while (edge != NULL) {
        pedge temp = edge;
        edge = edge -> next;
        free(temp);
    }
    temp_node -> edges = NULL;
}

void delete_node_cmd(pnode *head) {
    int src;
    scanf("%d", &src);
    pnode runner = *head;
    pnode temp;
    pnode temp2;
    pnode prev = NULL;
    while (runner != NULL) {
        pnode node = runner;
        if (node -> id != src) {
            delete_in_edge(node, src);
        } else {
            temp = node;
            temp2 = prev;
            free_node_edges(node);
        }
        prev = node;
        runner = runner -> next;
    }
    if (temp == *head) {
        *head = temp -> next;
        free(temp);
    } else {
        temp2 -> next = temp -> next;
        free(temp); 
    }       
}

void free_graph(pnode *head) {
    pnode node = *head;
    pnode prev;
    while (node != NULL) {
        prev = node;
        node = node -> next;
        free_node_edges(prev);
        free(prev);
    }
    *head = NULL;
}

//find node function - return node pointer or null if no such node
pnode get_node(pnode *head, int id) {
    pnode temp_node = *head;
    while (temp_node != NULL) {
        if (temp_node -> id == id) {
            return temp_node;
        }
        temp_node = temp_node -> next;
    }
    return NULL;
}

//set all nodes distaces and tags
void reset_dists_and_tags(pnode *head) {
    pnode temp_node = *head;
    while (temp_node != NULL) {
        temp_node -> dist = Max_Value; 
        temp_node -> tag = White;
        temp_node = temp_node -> next;
    }
}

pnode get_min_dist_node(pnode *head) {
    int min_dist = Max_Value;
    pnode runner = *head;
    pnode ans = NULL;
    while (runner != NULL) {
        if ((runner -> dist) < min_dist && (runner -> tag) != Black) {
            min_dist = runner -> dist;
            ans = runner;
        }
        runner = runner -> next;
    }
    return ans;
}

int dijkstra(pnode *head, int src_index, int dest_index) {
    pnode src_node = get_node(head, src_index);
    pnode dest_node = get_node(head, dest_index);
    if (src_node == NULL || dest_node == NULL) {
        return -1;
    }
    reset_dists_and_tags(head);
    src_node -> dist = 0;
    while (1) {
        pnode u = get_min_dist_node(head); 
        if (u == NULL) {
            return (dest_node -> dist);
        } else {
            u -> tag = Black;
            pedge edge = u -> edges;
            while (edge != NULL) {
                int endpoint = edge -> endpoint;
                pnode v = get_node(head, endpoint);
                int distance = (u -> dist) + (edge -> weight);
                if (distance < (v -> dist)) {
                    v -> dist = distance;
                }
                edge = edge -> next;
            }
        }
    }
}

void shortsPath_cmd(pnode *head) {
    int src_index, dest_index;
    scanf("%d%d", &src_index, &dest_index);
    int dist = dijkstra(head, src_index, dest_index);
    if (dist == Max_Value) {
        printf("-1");
    } else {
        printf("%d", dist);
    }  
}

void insert_new_node_cmd(pnode *head) {
    int id;
    pnode new_node;
    pedge new_edge;
    int endpoint;
    int weight;
    scanf("%d", &id);
    pnode temp_node = get_node(head, id);
    if (temp_node == NULL) {
        new_node = (pnode) malloc (sizeof(node));
        new_node -> id = id;
        new_node -> next = NULL;
    } else {
        free_node_edges(temp_node);
        new_node = temp_node;
    }
    while (scanf("%d", &endpoint)) {
        scanf("%d", &weight);
        new_edge = (pedge) malloc(sizeof(edge));
        new_edge -> endpoint = endpoint;
        new_edge -> weight = weight;
        new_edge ->next = NULL;
        if (new_node -> edges == NULL) {
            new_node -> edges = new_edge;
        } 
        else {
            pedge last_edge = new_node -> edges;
            while (last_edge -> next != NULL) {
                last_edge = last_edge -> next;
                printf("%p\n" , last_edge);
            }
            last_edge -> next = new_edge;
        }
    }
    
}

void insert_node_cmd(pnode *head) {
    int id;
    pnode new_node;
    pedge new_edge;
    int endpoint;
    int weight;
    scanf("%d", &id);

    if (*head == NULL) {
        pnode n1 = (pnode) malloc (sizeof(node));
        *head = n1;
        n1 -> id = id;
        n1 -> next = NULL;
        while (scanf("%d", &endpoint)) {
            scanf("%d", &weight);
            new_edge = (pedge) malloc(sizeof(edge));
            new_edge -> endpoint = endpoint;
            new_edge -> weight = weight;
            new_edge -> next = NULL;
            if (n1 -> edges == NULL) {
                n1 -> edges = new_edge;          
            } else {
                pedge last_edge = n1 -> edges;
                while (last_edge ->next != NULL) {
                    last_edge = last_edge ->next;
                }
                last_edge ->next = new_edge;
            }  
        }
    } else {
        new_node = (pnode) malloc (sizeof(node));
        new_node -> id = id;
        new_node -> next = NULL;
        pnode last_node = *head;
        while (last_node -> next != NULL) {
            last_node = last_node -> next;
        }
        last_node -> next = new_node;
        while (scanf("%d", &endpoint)) {
            scanf("%d", &weight);
            new_edge = (pedge) malloc(sizeof(edge));
            new_edge -> endpoint = endpoint;
            new_edge -> weight = weight;
            new_edge -> next = NULL;
            if (new_node -> edges == NULL) {
                new_node -> edges = new_edge;
            } else {
                pedge last_edge = new_node -> edges;
                while (last_edge ->next != NULL) {
                    last_edge = last_edge ->next;
                }
                last_edge ->next = new_edge;
            } 
        }
    }
}

void build_graph_cmd(pnode *head) {
    if (*head != NULL) {
        free_graph(head);
    }
    int vertices;
    scanf("%d", &vertices);
    char c;
    int i = 0;
    while (i < vertices) {
        scanf("%c", &c);
        if (c == n) {
            insert_node_cmd(head);
            i++;
        }    
    }
}
